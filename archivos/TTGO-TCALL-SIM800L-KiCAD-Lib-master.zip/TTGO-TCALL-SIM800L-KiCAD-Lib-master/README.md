# TTGO-TCALL-SIM800L-KiCAD-Lib
TTGO-TCALL-SIM800L-KiCAD-Lib

![image](https://user-images.githubusercontent.com/28555587/95006415-ed4f0b80-0621-11eb-8cda-f2561243a9c3.png)

## Footprint

![image](https://user-images.githubusercontent.com/28555587/94235241-dd9c3c80-ff28-11ea-89d0-80ac7eeb3345.png)



## Symbol
![image](https://user-images.githubusercontent.com/28555587/94235093-a168dc00-ff28-11ea-9cf3-e3f33718600c.png)
