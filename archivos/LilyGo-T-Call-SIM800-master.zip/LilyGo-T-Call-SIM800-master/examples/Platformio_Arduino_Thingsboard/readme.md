# Example project for Platformio

- Connecting to Thingsboard and sending telemetry battery/rssi/bootcount via MQTT
- Sleeping ESP32 & SIM800 (~1mA consumption)